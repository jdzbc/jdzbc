let questions = [
  {
  numb: 1,
  question: "¿Cuál es el lenguaje estándar específico para aplicar estilos de presentación a nuestras páginas web?",
  answer: "CSS",
  options: [
    "Javascript",
    "CSS",
    "PHP",
    "Flash"
  ]
},
  {
  numb: 2,
  question: ". ¿Qué significa la sigla HTML?",
  answer: "Hypertext Markup Language",
  options: [
    "Hypertext Manual Language",
    "Hypertext Markup Language",
    "Hypertext Match Language",
    "Sign Language HTML"
  ]
},
  {
  numb: 3,
  question: "¿Qué atributo de HTML se emplea en un formulario para especificar la página ala que se van a enviar los datos del mismo?",
  answer: "action",
  options: [
    "file",
    "method",
    "name",
    "action"
  ]
},
  {
  numb: 4,
  question: "¿Qué significa CSS?",
  answer: "Cascading Style Sheets",
  options: [
    "Color Style Sheets",
    "Cascading Style Sheets",
    "Creative Style Sheets",
    " Computer Style Sheets"
  ]
},
  {
  numb: 5,
  question: "¿Qué significa XML?",
  answer: "eXtensible Markup Language",
  options: [
    "eXtensible Markup Language",
    "eXecutable Multiple Language",
    "eXTra Multi-Program Language",
    "eXamine Multiple Language"
  ]
},
];
